package com.cts.entities;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;
@Entity
@Table(name="CTSBooking")
public class Booking {
/*@AttributeOverride(name="customer,column=@Column(name="Cts_Cust_id"))
 @AttributeOverrides({
			@AttributeOverride(name = "event_id", column = @Column(name = "event_id")),
			@AttributeOverride(name = "cust_id", column = @Column(name = "cust_id")) })
*/
@EmbeddedId
private Bookingc bookingId;
@Column(name="Tickets_Booked")
private int ticketsBooked;
@Column(name="Amount")
private int amount;
public Bookingc getBookingId() {
	return bookingId;
}
public void setBookingId(Bookingc bookingId) {
	this.bookingId = bookingId;
}
public int getTicketsBooked() {
	return ticketsBooked;
}
public void setTicketsBooked(int ticketsBooked) {
	this.ticketsBooked = ticketsBooked;
}
public int getAmount() {
	return amount;
}
public void setAmount(int amount) {
	this.amount = amount;
}

}

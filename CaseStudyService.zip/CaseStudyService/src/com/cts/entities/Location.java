package com.cts.entities;

import javax.persistence.Cacheable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;
//Bookings
@XmlRootElement
@Cacheable

@Entity
@Table(name="CTSLocation")
@NamedQuery(name="GetLocationByName",query="from Location loc where loc.locationName=?")
public class Location {
@Id
@GeneratedValue(strategy=GenerationType.IDENTITY)
@Column(name="Location_Id")
private int locationId;
	@Column(name="Location_Name")
private String locationName;
public int getLocationId() {
	return locationId;
}
public void setLocationId(int locationId) {
	this.locationId = locationId;
}
public String getLocationName() {
	return locationName;
}
public void setLocationName(String locationName) {
	this.locationName = locationName;
}

}
